# CM5-DETECT rev0.3 — V1_RU_Rezonit_CM5

* Завод: Резонит (Россия)
* Стек: Резонит «4 Layers (1,5mm 18um Tg150 Impedance)», толщина 1,5 мм
* Модуль: Raspberry Pi CM5 (CM5108032: 8 GB LPDDR4X, 32 GB eMMC, Wi-Fi)

Папки: 01_Photos (рендеры), 02_Components (BOM), 03_Functionality (функции, подключение, заказ, прошивки),
04_Gerber (Gerber/сверловка/BOM/CPL для завода), 05_KiCad_project (KiCad 9 + генераторы), 06_Checks_and_calculations (DRC, импеданс).
