# CM5-DETECT rev0.3 — V3_HYBRID_RK3576

* Завод: Резонит или JLCPCB (та же плата)
* Стек: как V1 или V2
* Модуль: CM5-совместимый модуль RK3576: Radxa CM4 / ArmSoM CM5 / Geniatech XPI-3576-CM5 (8 ГБ, eMMC 32–64 ГБ, NPU 6 TOPS)

Папки: 01_Photos (рендеры), 02_Components (BOM), 03_Functionality (функции, подключение, заказ, прошивки),
04_Gerber (Gerber/сверловка/BOM/CPL для завода), 05_KiCad_project (KiCad 9 + генераторы), 06_Checks_and_calculations (DRC, импеданс).
