# CM5-DETECT rev0.3 — V2_CN_JLCPCB_CM5

* Завод: JLCPCB (Китай)
* Стек: JLC04161H-3313, 1,6 мм, Impedance Control = Yes (100 Ом диф / 90 Ом USB)
* Модуль: Raspberry Pi CM5 (CM5108032: 8 GB LPDDR4X, 32 GB eMMC, Wi-Fi)

Папки: 01_Photos (рендеры), 02_Components (BOM), 03_Functionality (функции, подключение, заказ, прошивки),
04_Gerber (Gerber/сверловка/BOM/CPL для завода), 05_KiCad_project (KiCad 9 + генераторы), 06_Checks_and_calculations (DRC, импеданс).
